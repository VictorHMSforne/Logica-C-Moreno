#include<stdio.h>
#include<stdlib.h>
#include <string.h>

#define tot 3
 
//defini��o da estrutura 
  typedef struct{
   char nome[50];
   char telefone[16];
   int idade;
 } pessoa;
//--------------------------------------------
//variaveis globais
 pessoa pe[tot];
 int x,y;
//--------------------------------------------
void entrada_pessoa();
void saida_pessoa();
void classifica_nome();
void classifica_telefone();
void classifica_idade();
void troca();
//--------------------------------------------
int main (){
int opcao;
  do {
    system("cls");
    printf("MENU\n");
    printf("1 - Entrada de dados\n");
    printf("2 - Classifica por nome\n");
    printf("3 - Classifica por telefone\n");
    printf("4 - Classifica por idade\n");
    printf("5 - Mostra dados\n");
    printf("6 - FIM\n");
    printf("opcao: ");
    scanf("%d",&opcao);
    switch (opcao){
      case 1: entrada_pessoa(); break;
      case 2: classifica_nome(); break;
      case 3: classifica_telefone(); break;
      case 4: classifica_idade(); break;
      case 5: saida_pessoa(); break;
    } 
  }
  while (opcao!=6);
  return 0;
}
//--------------------------------------------
void entrada_pessoa(){
  for (int x=0; x<tot; x++){
    printf("Pessoa %d \n",x+1);
    printf("Nome: ");
    fflush(stdin);
    gets(pe[x].nome);
    fflush(stdin);
    
    printf("Fone: ");
    gets(pe[x].telefone);
    fflush(stdin);
    
    printf("Idade: ");
    scanf("%d",&pe[x].idade);
    fflush(stdin);
    printf("-------------------------------------------\n");
  }
}
//--------------------------------------------
void saida_pessoa(){
  for (int x=0; x<tot; x++){
    printf("Pessoa %d \n",x+1);
    printf("Nome: %s\n",pe[x].nome);
    printf("Fone: %s\n",pe[x].telefone);
    printf("Idade: %d\n",pe[x].idade);
    printf("-------------------------------------------\n");
  }
  system("pause");
}
//--------------------------------------------
void classifica_nome(){
  for (x=0; x<tot-1; x++)
    for (y=x+1; y<tot; y++)
      if (strcmp(pe[y].nome,pe[x].nome)==-1)
          troca();
}
//-------------------------------------------
void classifica_telefone(){
  for (x=0; x<tot-1; x++)
    for (y=x+1; y<tot; y++)
      if (strcmp(pe[y].telefone,pe[x].telefone)==-1)
          troca();
}
//-------------------------------------------
void classifica_idade(){
  for (x=0; x<tot-1; x++)
    for (y=x+1; y<tot; y++)
      if (pe[y].idade < pe[x].idade)
          troca();

}
//-------------------------------------------
void troca(){
pessoa temp;
   temp=pe[y];
  pe[y]=pe[x];
  pe[x]=temp;
}
