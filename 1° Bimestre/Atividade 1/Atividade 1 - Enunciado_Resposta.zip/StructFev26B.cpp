//Esta � a versao melhorada utilizando o void troca com passagem de ponteiro
//Obs. o preenche � um precedimento para preencher o vetor sem necessidade de
//digita��o para facilitar os testes.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define tot 5
//defini��o da estrutura 
  typedef struct{
   char nome[50];
   char telefone[16];
   short int idade;
 } pessoa;
//variaveis globais
 pessoa pe[tot];
//prototipa��o das sub-rotinas
void entrada_pessoa();
void saida_pessoa();
void classifica_nome();
void classifica_telefone();
void classifica_idade();
void troca(pessoa *p1, pessoa *p2);

void preenche();
//--------------------------------------------
int main (){
short int opcao;
  
  
  preenche();
  do {
    system("cls");
    printf("MENU\n");
    printf("1 - Entrada de dados\n");
    printf("2 - Classifica por nome\n");
    printf("3 - Classifica por telefone\n");
    printf("4 - Classifica por idade\n");
    printf("5 - Mostra dados\n");
    printf("6 - FIM\n");
    printf("opcao: ");
    scanf("%d",&opcao);
    switch (opcao){
      case 1: entrada_pessoa(); break;
      case 2: classifica_nome(); break;
      case 3: classifica_telefone(); break;
      case 4: classifica_idade(); break;
      case 5: saida_pessoa(); break;
    } 
  }
  while (opcao!=6);
  return 0;
}
//--------------------------------------------
void preenche(){
  strcpy(pe[0].nome,"Jose Claudio");
  strcpy(pe[0].telefone,"(41) 9920-9092");
  pe[0].idade=25;
  
  strcpy(pe[1].nome,"Ana Claudia");
  strcpy(pe[1].telefone,"(47) 8432-1020");
  pe[1].idade=41;
  
  strcpy(pe[2].nome,"Marcos Antonio");
  strcpy(pe[2].telefone,"(44) 8410-0001");
  pe[2].idade=17;
  
  strcpy(pe[3].nome,"Barbara Dantas");
  strcpy(pe[3].telefone,"(44) 9994-5430");
  pe[3].idade=53;
  
  strcpy(pe[4].nome,"Carlos Pacheco");
  strcpy(pe[4].telefone,"(42) 9999-5090");
  pe[4].idade=19;
  
}
//--------------------------------------------
void entrada_pessoa(){
  for (short int x=0; x<tot; x++){
    printf("Pessoa %d \n",x+1);

    printf("Nome: ");
    fflush(stdin);   //limpa buffer do teclado
    gets(pe[x].nome);
    
    printf("Fone: ");
    fflush(stdin);   //limpa buffer do teclado
    gets(pe[x].telefone);
    
    printf("Idade: ");
    fflush(stdin);   //limpa buffer do teclado
    scanf("%d",&pe[x].idade);

    printf("-------------------------------------------\n");
  }
}
//--------------------------------------------
void saida_pessoa(){
  printf("Id                 Nome             Fone  idade\n");
  printf("------------------------------------------------\n");
  for (short int x=0; x<tot; x++)
    printf("%2d %20s %16s %6d \n",x+1,pe[x].nome,pe[x].telefone,pe[x].idade);
  printf("------------------------------------------------\n");
  system("pause");
}
//--------------------------------------------
void classifica_nome(){
  for (short int x=0; x<tot-1; x++)
    for (short int y=x+1; y<tot; y++)
      if (strcmp(pe[y].nome,pe[x].nome)==-1)
          troca(&pe[x],&pe[y]);
}
//-------------------------------------------
void classifica_telefone(){
  for (short int x=0; x<tot-1; x++)
    for (short int y=x+1; y<tot; y++)
      if (strcmp(pe[y].telefone,pe[x].telefone)==-1)
          troca(&pe[x],&pe[y]);
}

//-------------------------------------------
void classifica_idade(){
  for (short int x=0; x<tot-1; x++)
    for (short int y=x+1; y<tot; y++)
      if (pe[y].idade < pe[x].idade)
          troca(&pe[x],&pe[y]);
}

//-------------------------------------------
void troca(pessoa *p1, pessoa *p2){
pessoa temp;
   temp=*p1;
    *p1=*p2;
    *p2=temp;
}

