#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	int x = 10, y=20, z=100, N = 24;
	char tc = 'c';

	int *ptr1, *ptr2, *ptr3, *ptrN;
	char *ptr4;
	
	ptr1=&x;
	ptr2=&y;
	ptr3=&z;
	ptr4=&tc;
	ptrN=&N;

	printf("valor x = %d\n", x);
	printf("valor y = %d\n", y);
	printf("valor z = %d\n", z);
	printf("valor N = %d\n", N);
	printf("valor tc = %c\n", tc);
	
	printf("----------------------------------\n");	
	
	printf("End. mem. x = %p\n", &x);
	printf("End. mem. y = %p\n", &y);
	printf("End. mem. z = %p\n", &z );
	printf("End. mem. N = %p\n", &N);
	printf("End. mem. tc = %p\n", &tc);
	
	printf("----------------------------------\n");	
	
	printf("End. mem. ptr1 = %p\n", &ptr1);
	printf("End. mem. ptr2 = %p\n", &ptr2);
	printf("End. mem. ptr3 = %p\n", &ptr3);
	printf("End. mem. ptr4 = %p\n", &ptr4);
	printf("End. mem. ptrN = %p\n", &ptrN);
	
	printf("----------------------------------\n");	
    	
	printf("Valor  ptr1  = %p\n", ptr1);
	printf("Valor  ptr2  = %p\n", ptr2);
	printf("Valor  ptr3  = %p\n", ptr3);
	printf("Valor  ptr4  = %p\n", ptr4);
	printf("Valor  ptrN  = %p\n", ptrN);
	
	printf("---------------------------------------------------------------\n");	
	
	printf("Vlr. onde ptr1 aponta = %d\n", *ptr1);
	printf("Vlr. onde ptr2 aponta = %d\n", *ptr2);
	printf("Vlr. onde ptr3 aponta = %d\n", *ptr3);
	printf("Vlr. onde ptr4 aponta = %d\n", *ptr4);
	printf("Vlr. onde ptrN aponta = %d\n", *ptrN);
	
	printf("----------------------------------\n");	
	
	printf("End. onde ptr1 aponta = %p\n", &*ptr1);
	printf("End. onde ptr2 aponta = %p\n", &*ptr2);
	printf("End. onde ptr3 aponta = %p\n", &*ptr3);
	printf("End. onde ptr4 aponta = %p\n", &*ptr4);
	printf("End. onde ptrN aponta = %p\n", &*ptrN);
	
	printf("----------------------------------\n");	
	//plus
	char nome[40];
	printf("Digite o nome: ");
    scanf("%[^\n]",nome);
    printf("End. de nome: %p\n",&nome);
    for (int i = 0; i<strlen(nome); i++)
      printf("End. caractere %c: %p\n",nome[i],&nome[i]);
    
	system (" pause ");
	return 0;
}
